import xipppy_capi as _c
from .exception import check

def hw_reference(elecs, enable):
    """ hardware reference switching for EEG and ECOG electrodes

        :param elecs:  list of electrodes
        :param enable: boolean flag to enable or disable
    """

    for elec in elecs:
        r = _c.xl_hw_reference(elec, bool(enable))
        if r < 0:
            print('Error setting reference for {}'.format(elec))




def hw_ground(elecs, enable):
    """ hardware ground switching for EEG and ECOG electrodes

        :param elecs:  list of electrodes to ground
        :param enable: boolean flag to enable or disable grounding
    """

    for elec in elecs:
        r = _c.xl_hw_ground(elec, bool(enable))
        if r < 0:
            print('Error setting ground for {}'.format(elec))


