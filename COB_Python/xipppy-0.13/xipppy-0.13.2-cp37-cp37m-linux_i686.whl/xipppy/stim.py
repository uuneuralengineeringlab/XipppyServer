import array
import ctypes

import xipppy_capi as _c
from .exception import check


def _fill_stim_seq(stimseq_t, words):
    stimseq_t.length = len(words)
    # SWIG treats arrays as pointers, so we need to make a pointer
    # and fill the array into there, then copy into the underlying C struct
    c_arr = array.array('i', words)
    assert (c_arr.itemsize == 4)
    ptr, buf_len = c_arr.buffer_info()
    sgn_ptr = int(ctypes.c_int(ptr).value)
    stimseq_t.fill_array(*c_arr.buffer_info())
    stimseq_t.fill_array(ptr, buf_len)


class StimSegment:
    STIM_LEVEL_AMP = 0
    NEURAL_AMP = 1

    def __init__(self, length, amplitude, polarity, enable=True, delay=0,
                 fast_settle=False, amp_select=NEURAL_AMP):
        """
        Create a stim segment. Multiple stim segments can be assembled to
        create a stim sequence.  For example, the simplest biphasic stim pulse
        could be constructed from two stim segments:

        StimSegment(10, 120, -1)
        StimSegment(10, 120, 1)

        :param length: Integer length of the stim segment in units of
          `nipclocks` which are 33.333 microseconds.
          For example, if length is 10 then this segment would be 333.33
          microseconds long. Must be in the range
          [1, 65535]
        :param amplitude: Integer amplitude in stim output steps. The current
          per step depends on the current stim resolution. Check the
          documentation for your device. Must be in the range [0, 127]

        :param enable: Boolean that determines whether current output is
          enabled. Defaults to True
        :param delay: Integer that delays this segment in increments of 1.04
          microseconds. Must be between [0, 31]. Defaults to 0.

        :param fast_settle: Boolean that enables fast settling. Defaults to
          False.
        :param amp_select: Select the amplifier that is enabled during this
          segment.
        """
        self._amp_select = None
        self._amplitude = None
        self._length = None
        self._enable = None
        self._delay = None
        self._fast_settle = None
        self._polarity = None

        self.length = length
        self.amplitude = amplitude
        self.enable = enable
        self.delay = delay
        self.fast_settle = fast_settle
        self.amp_select = amp_select
        self.polarity = polarity

    def _make_word(self):
        word = _c.xl_stim_word(
            self.length, self.amplitude, self.polarity + 1, self.enable,
            self.amp_select, self.delay, self.fast_settle)
        return word

    @property
    def amplitude(self):
        return self._amplitude

    @amplitude.setter
    def amplitude(self, value):
        if 0 <= value <= 127:
            self._amplitude = value
        else:
            raise ValueError("amplitude should be in the range [0, 127]")

    @property
    def length(self):
        return self._length

    @length.setter
    def length(self, value):
        if 1 <= value <= 0xFFFF:
            self._length = value
        else:
            raise ValueError('repeats should be in the '
                             'range [1, {0}]'.format(0xFFFF))

    @property
    def polarity(self):
        return self._polarity

    @polarity.setter
    def polarity(self, value):
        if value in {-1, 1}:
            self._polarity = value
        else:
            raise ValueError('polarity should be 1 or -1')

    @property
    def enable(self):
        return self._enable

    @enable.setter
    def enable(self, value):
        if value in {False, True}:
            self._enable = value
        else:
            raise ValueError('enable should be True or False')

    @property
    def amp_select(self):
        return self._amp_select

    @amp_select.setter
    def amp_select(self, value):
        if value in {StimSegment.STIM_LEVEL_AMP, StimSegment.NEURAL_AMP}:
            self._amp_select = value
        else:
            raise ValueError('amp_select should be StimSegment.STIM_LEVEL_AMP '
                             'or StimeSegment.NEURAL_AMP')

    @property
    def delay(self):
        return self._delay

    @delay.setter
    def delay(self, value):
        if 0 <= value < 32:
            self._delay = value
        else:
            raise ValueError('delay should be in the range [0, 31]')

    @property
    def fast_settle(self):
        return self._fast_settle

    @fast_settle.setter
    def fast_settle(self, value):
        if value in {True, False}:
            self._fast_settle = value
        else:
            raise ValueError('fast_settle should be True or False')


class StimSeq:
    STIM_IMMED = 0
    STIM_CURCYC = 1
    STIM_ALLCYC = 2
    STIM_TRIGGER = 3
    STIM_AT_TIME = 4
    GVSTIM_CMD_MAXLEN = 249

    def __init__(self, electrode, period, repeats, *segments,
                 action=STIM_IMMED):
        """
        Creates a stim sequence
        :param electrode:
        :param period:
        :param repeats:
        :param action:
        """
        self._electrode = None
        self._period = None
        self._repeats = None
        self._action = None
        self._segments = None

        self.electrode = electrode
        self.period = period
        self.repeats = repeats
        self.action = action
        self.segments = segments

    @property
    def electrode(self):
        return self._electrode

    @electrode.setter
    def electrode(self, value):
        if 0 <= value <= 511:
            self._electrode = value
        else:
            raise ValueError('electrode should be in the range [0, 511]')

    @property
    def period(self):
        return self._period

    @period.setter
    def period(self, value):
        if 0 <= value <= 0xFFFF:
            self._period = value
        else:
            raise ValueError('period should be in '
                             'the range [0, {0}]'.format(0xFFFF))

    @property
    def repeats(self):
        return self._repeats

    @repeats.setter
    def repeats(self, value):
        if 0 <= value <= 0xFFF:
            self._repeats = value
        else:
            raise ValueError('repeats should be in the range [0, 4095]')

    @property
    def action(self):
        return self._action

    @action.setter
    def action(self, value):
        if 0 <= value <= 4:
            self._action = value
        else:
            raise ValueError('action should be one of STIM_IMMED, '
                             'STIM_CURCYC, STIM_ALLCYC, STIM_TRIGGER,'
                             'STIM_AT_TIME')

    @property
    def segments(self):
        return self._segments

    @segments.setter
    def segments(self, value):
        if len(value) > StimSeq.GVSTIM_CMD_MAXLEN:
            raise ValueError('A stim sequence can have '
                             'no more than {0} segments'
                             .format(StimSeq.GVSTIM_CMD_MAXLEN))
        try:
            for seg in value:
                assert (isinstance(seg, StimSegment))
            self._segments = value
        except:
            raise ValueError('segments must be a list of StimSegment objects')

    def send(self):
        """
        Send this single StimSeq. If you'd like to send many StimSeqs
        simultaneously, consider
        calling StimSeq.send_stim_seqs on a list of StimSeq objects.
        """
        StimSeq.send_stim_seqs([self])

    def _make_seq(self):
        """
        Creates a SimSeq_t struct and fills its array with command words
        generated from
        segments. It shouldn't be necessary to invoke this directly.
        :return:
        """
        stimseq_t = _c.StimSeq_t()
        stimseq_t.elec = self.electrode
        header = _c.xl_stim_header_word(self.action, self.period, self.repeats)
        words = [header] + [seg._make_word() for seg in self.segments]
        _fill_stim_seq(stimseq_t, words)
        return stimseq_t

    @staticmethod
    def send_stim_seqs(seqs):
        """
        Takes a list of StimSeq objects and packs them into an
        array before sending to the NIP. If the total size of
        all the stim sequences is less than 1500 bytes, the stim sequences
        will execute synchronously with precise timing.

        :param seqs: a list of StimSeq objects
        """
        arr = _c.StimSeqArray(len(seqs))
        for i, seq in enumerate(seqs):
            if 0 < len(seq.segments) < StimSeq.GVSTIM_CMD_MAXLEN:
                arr[i] = seq._make_seq()
            else:
                raise RuntimeError(
                    'A stim sequence must have a number of stim'
                    ' segments in the range [0, {0}]'
                        .format(StimSeq.GVSTIM_CMD_MAXLEN))

        _c.xl_stim_seq(arr, len(seqs))


def stim_enable():
    """Get the global enable state for stim (True for enabled)."""
    return bool(check(_c.xl_stim_enable()))


def stim_enable_set(val):
    """
    Set the global enable for stim (True to enable or False to disable).
    Args:
        val:
    """
    return bool(check(_c.xl_stim_enable_set(int(val))))


def stim_get_res(elec):
    """
    Get stim resolution for elec
    """

    res = ctypes.c_int(0)
    check(_c.xl_stim_get_res(elec, ctypes.addressof(res)))
    return res.value


def stim_set_res(elec, level):
    """
    Set stim resolution for electrode
    """
    check(_c.xl_stim_set_res(elec, level))

def stim_get_exhaust(elec):
    """
    Get stim exhaust resistor value for elec
    """

    res = ctypes.c_int(0)
    check(_c.xl_stim_get_exhaust(elec, ctypes.addressof(res)))
    return res.value


def stim_set_exhaust(elec, res_opt):
    """
    Set stim exhaust resistor value for electrode
    """
    check(_c.xl_stim_set_exhaust(elec, res_opt))
