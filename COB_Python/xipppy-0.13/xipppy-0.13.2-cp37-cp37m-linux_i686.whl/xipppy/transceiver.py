import array
import ctypes
import itertools
import logging
import time
from enum import IntEnum
from enum import unique

import xipppy_capi as _c

from .exception import check

logger = logging.getLogger(__name__)

TRANSCEIVER_STATUS_COUNTER_MAX = 255
IMPLANT_BOOTING_COUNTER_MAX = 10
DEFAULT_SERVO_DAC_LEVEL = 0x92
FW_PKT_SIZE = 32

POWER_STATE_R3 = {
    'idle': 0,
    'ir_enable': 1,
    'coil_enable': 2,
    'servo_enable': 3,
    'booting_coil_on': 4,
    'booting_coil_off': 5
}

IMPLANT_VOLTAGE_STATE = {
    'default': 3.5,
    'boosted': 4.0
}


class TransceiverCmdHeader:
    CMD = 0xc << 12
    IMPLANT_WRITE = CMD | (0b10 << 4)
    TRANSCEIVER_WRITE = CMD | (0b01 << 4)
    CFG_WRITE = CMD | (0b11 << 4)
    IMPLANT_READ = IMPLANT_WRITE | 0b01
    TRANSCEIVER_READ = TRANSCEIVER_WRITE | 0b01
    CFG_READ = CFG_WRITE | 0b01


class TransceiverRegisterAddrs:
    DEMOD_LATCH_DELAY_COUNT = 0x01
    COIL_PULSE_WIDTH = 0x02
    COIL_BLANK_COUNT = 0x03
    MANUAL_CONTROL_COIL_IR = 0x04
    COIL_ENABLE_BITS = 0x05
    IR_ENABLE_BITS = 0x06
    COIL_DRIVE_DAC = 0x07
    DEMOD_FILTER_DISABLE = 0x08
    POWER_SUPPLY_ENABLE_5V = 0x09
    COIL_BLANK_PERIOD = 0x0a
    LINK_ENABLE_COIL_IR = 0x0b
    IMPLANT_SERVO_DAC_TARGET = 0x0c
    IMPLANT_SERVO_ENABLE = 0x0d
    ADC_I2C_ACCESS = 0x0e
    CFG_SEC1_PAGE0 = 0x47
    CFG_SEC0_PAGE0 = 0x46


class ImplantRegisterAddrs:
    # Non-ASIC
    IMPEDANCE_CONTROL = 0x1
    FAST_SETTLE_ENABLE = 0x2
    SW_REF_CONFIG = 0x4
    LED_PROM_CONFIG = 0x15
    RECORDING_RESOLUTION = 0x40
    # ASIC
    AMP_LOWER_BANDWIDTH_SELECT = 0x100
    AMP_UPPER_BANDWIDTH_SELECT_1 = 0x101
    AMP_UPPER_BANDWIDTH_SELECT_2 = 0x102
    AMPLIFIER_POWER_1 = 0x103
    AMPLIFIER_POWER_2 = 0x104
    MUX_BIAS_CURRENT_AND_COUNTER = 0x105
    IMPEDANCE_CHECK = 0x106
    ROM_CHECKSUM_2 = 0x0117  # Read only
    ROM_CHECKSUM_1 = 0x0118  # Read only
    NUM_AMPLIFIERS = 0x119  # Read only


@unique
class TransceiverStatus(IntEnum):
    NOT_USED = 0
    REGISTER_ADDR = 1
    REGISTER_DATA = 2
    RNUM = 3
    SERIAL_NUM = 4
    HW_FW_VER = 5
    IR_LIGHT_AMP_AND_SERVO_STATE = 6
    TEMP_AND_RESERVED = 7
    INPUT_SUPPLY_CURRENT_AND_VOLTAGE_ADC = 8
    COIL_SUPPLY_CURRENT_AND_VOLTAGE_ADC = 9
    RESERVED_1 = 10
    RESERVED_2 = 11
    IMPLANT_RNUM = 12
    IMPLANT_SERIAL_NUM = 13
    IMPLANT_FW_HW_VER = 14
    IMPLANT_CURRENT_AND_VOLTAGE_ADC = 15
    IMPLANT_PACKET_COUNT = 16
    MICS_CONF_LED_PROM = 17
    SARA_ASIC_STATUS = 18
    SARA_IMPLANT_2_6_V_CURRENT_AND_VOLTAGE_ADC = 19
    SARA_STIM_NEG_AND_POS_VOLTAGE_ADC = 20
    SARA_STIM_CURRENT_ADC = 21
    SARA_IMPEDANCE_STATUS = 22
    SARA_IMPEDANCE_FREQ_AND_CLOCK_SKEW = 23
    SARA_HUMID_AND_TEMP = 24
    RESERVED_3 = 25
    RESERVED_4 = 26
    RESERVED_5 = 27
    RESERVED_6 = 28
    RESERVED_7 = 29
    RESERVED_8 = 30
    RESERVED_9 = 31


class TransceiverFlashCommand:
    CFG_ENABLE_TRANSPARENT = 0x74
    CFG_ERASE_FALSH = 0x0e
    WRITE_TO_FLASH = 0xc9
    DISABLE_CFG_INTERFACE = 0x26
    WRITE_TO_CFG_FLASH = 0x70
    PROGRAM_DONE = 0x5e


class TransceiverCommand:
    MIN_I16 = -32768
    MAX_U16 = 65535

    def __init__(self, command=0, data=None):
        if data is None:
            data = []

        self.command = command
        self._data = []

        self.data = data

    @property
    def data(self):
        return self._data

    @data.setter
    def data(self, new_data):
        data = []

        for n in new_data:
            n = int(n)
            if n < self.MIN_I16 or n > self.MAX_U16:
                raise TypeError('unable to convert data to an int16')

            val = ctypes.c_uint16(n)
            data.append(val.value)

        self._data = data

    @property
    def length(self):
        return len(self._data)

    def cast(self):
        cmd = _c.XippTransceiverCommand_t()
        cmd.command = self.command
        cmd.length = self.length
        cmd.data = self.data
        return cmd


class TransceiverConfigurationData:
    """
    This class will create required pattern for Transceiver firmware
    configuration commands and will send the command to the Transceiver.
    The first 3 words of configuration data must be 0 since they are not used.
    All other not-used data should be 0xFFFF.
    """
    MIN_I16 = -32768
    MAX_U16 = 65535

    def __init__(self):
        self._fw_data = []
        for _ in range(3):
            self.push(0)

    @property
    def data(self):
        return self._fw_data

    @data.setter
    def data(self, new_data):
        self._fw_data = new_data

    def push(self, word):
        if word < self.MIN_I16 or word > self.MAX_U16:
            raise TypeError('unable to convert data to an int16')
        new_data = self.data
        new_data.append(word)
        self.data = new_data

    def send(self, elec):
        for _ in range(len(self.data), FW_PKT_SIZE):
            self.push(0xFFFF)
        xcvr_cmd = TransceiverCommand(
            TransceiverCmdHeader.CFG_WRITE,
            self.data
        )
        transceiver_command(elec, xcvr_cmd)


def transceiver_enable(elec, enable=True):
    """
    Enable or disable front end of the electrode

    Parameters
    ----------
    elec: int
       electrode number (0-511)

    enable: boolean
        flag whether to enable or disable the front end
    """

    check(_c.xl_transceiver_enable(int(elec), bool(enable)))


def transceiver_status(elec):
    """
    Get most recent status from transceiver of the electrode

    Parameters
    ---------
    elec: int
       electrode number (0-511)

    returns: array of uint16_t containing the status
    """

    result = array.array('H', itertools.repeat(0, 32))
    check(_c.xl_transceiver_status(result.buffer_info()[0], elec))
    return result


def transceiver_command(elec, command):
    """
    Send command to transceiver at front end of the electrode

    Parameters
    ----------
    elec: int
       electrode number (0-511)

    command: TransceiverCommand
        object of type TransceiverCommand specifying the command to send
    """

    if isinstance(command, TransceiverCommand):
        cmd_t = command.cast()
    elif isinstance(command, _c.XippTransceiverCommand_t):
        cmd_t = command
    else:
        raise ValueError('command is required to be Transceiver command type')

    check(_c.xl_transceiver_command(elec, cmd_t))


def high_byte(light_servo):
    return light_servo & 0b1111111100000000


def low_byte(light_servo):
    return light_servo & 0b0000000011111111


def transceiver_power_servo_enable(state: bool, elec: int = 0) -> None:
    """
    This sets the implant power servo state. This ultimately affects a property
    of the implant. But, the state is held in a transceiver register so it
    persists through implant restarts due to power loss.

    :param state: True for enabled, False for disabled.
    """
    cmd = TransceiverCommand(
        TransceiverCmdHeader.TRANSCEIVER_WRITE,
        [0, TransceiverRegisterAddrs.IMPLANT_SERVO_ENABLE, int(state)]
    )
    transceiver_command(elec, cmd)


def transceiver_get_ir_received_light(elec: int = 0) -> float:
    """
    Return the light amplitude, in arbitrary voltage units, that is measured
    by the transceiver photodiode.
    """
    light_servo = transceiver_status(elec)[
        TransceiverStatus.IR_LIGHT_AMP_AND_SERVO_STATE
    ]
    light_adc = light_servo & 0b1111111000000
    scaled_volt = light_adc * (1 / 256.0) * 4.096
    return scaled_volt


def transceiver_get_power_state(elec: int = 0) -> int:
    """
    Return the power state for the implant. This can be used to detect whether
    the implant is booted. See POWER_STATE_R3 for mapping of descriptions to
    power state number returned by this function.
    """
    light_servo = transceiver_status(elec)[
        TransceiverStatus.IR_LIGHT_AMP_AND_SERVO_STATE
    ]
    servo = light_servo & 0b111
    return servo


def transceiver_get_implant_voltage(elec: int = 0) -> float:
    """
    Return the current power supply voltage for the connected implant.
    """
    curr_volt_adc = transceiver_status(elec)[
        TransceiverStatus.IMPLANT_CURRENT_AND_VOLTAGE_ADC
    ]
    volt_adc = low_byte(curr_volt_adc)
    scaled_volts = (2.5 * ((float(volt_adc)) / 256)) / (57.6 / (76.8 + 57.6))
    return scaled_volts


def transceiver_get_implant_serial(elec: int = 0) -> int:
    """
    Return the connected implant serial number.
    :return:
    """
    return transceiver_status(elec)[TransceiverStatus.IMPLANT_SERIAL_NUM]


def transceiver_get_ir_led_level(elec: int = 0) -> int:
    """
    Query the current IR LED light level reported by the transceiver. The value
    is in the range 0 to 15 inclusive. But, the low levels, especially 0 can
    never been reported as real values because the IR is used to report the
    light levels, so it's impossible to report light levels below a certain
    level.
    """
    mics_led = transceiver_status(elec)[
        TransceiverStatus.MICS_CONF_LED_PROM
    ]
    # Mask out the MICS part.
    led = mics_led & 0b0000000011111111
    return led


def transceiver_set_implant_servo_dac(
        target: int = DEFAULT_SERVO_DAC_LEVEL, elec: int = 0) -> None:
    """
    Set the target DAC value for the transceiver coil driver voltage.


    :param target: Set the target DAC value. If this value is None, then the
    :param elec: electrode index (0-511)

    default, 0x92, is set.
    """
    cmd = TransceiverCommand(
        TransceiverCmdHeader.TRANSCEIVER_WRITE,
        [0, TransceiverRegisterAddrs.IMPLANT_SERVO_DAC_TARGET, target]
    )
    transceiver_command(elec, cmd)


def transceiver_enable_ir_coil(target: int, elec: int = 0):
    """
    Switch ir-link between transceiver and implants
    :param target: True for On, False for Off
    :param elec: electrode index (0-511)
    """
    cmd = TransceiverCommand(
        TransceiverCmdHeader.TRANSCEIVER_WRITE,
        [0, TransceiverRegisterAddrs.LINK_ENABLE_COIL_IR, target]
    )
    transceiver_command(elec, cmd)


def transceiver_disable_adc_i2c_access(elec: int = 0):
    """
    The embedded function block (EFB) in the FPGA includes both the hardened I2C
    core and configuration/user flash memory (CFG/UFM) function access.
    Accesses to the I2C need to cease during CFG/UFM access to avoid conflicts.
    """
    cmd = TransceiverCommand(
        TransceiverCmdHeader.TRANSCEIVER_WRITE,
        [0, TransceiverRegisterAddrs.ADC_I2C_ACCESS, 0]
    )
    transceiver_command(elec, cmd)


def transceiver_enable_adc_i2c_access(elec: int = 0):
    """
    The embedded function block (EFB) in the FPGA includes both the hardened I2C
    core and configuration/user flash memory (CFG/UFM) function access.
    Accesses to the I2C need to cease during CFG/UFM access to avoid conflicts.
    """
    cmd = TransceiverCommand(
        TransceiverCmdHeader.TRANSCEIVER_WRITE,
        [0, TransceiverRegisterAddrs.ADC_I2C_ACCESS, 1]
    )
    transceiver_command(elec, cmd)


def transceiver_send_cfg_cmd(cmd, elec):
    """
    Send customized config command where the operand is 0x08.
    :param cmd: 2bit cfg command
    :param elec: electrode index (0-511)
    """
    config_data = TransceiverConfigurationData()
    config_data.push(0x0400)
    config_data.push((0x08 << 8) | cmd)
    config_data.push(0)

    config_data.send(elec)


def transceiver_enable_cfg_transparent(elec: int = 0):
    transceiver_send_cfg_cmd(TransceiverFlashCommand.CFG_ENABLE_TRANSPARENT,
                             elec)


def transceiver_erase_ufm_flash(elec: int = 0):
    """
    Erase the user flash memory.
    """
    transceiver_send_cfg_cmd(TransceiverFlashCommand.CFG_ERASE_FALSH, elec)


def transceiver_reset_ufm_flash(cmd, elec: int = 0):
    """
    Reset the user flash memory with the provided sector and page address
    param cmd: sector and page
    """
    config_data = TransceiverConfigurationData()
    config_data.push(0x0400)
    config_data.push(cmd)
    config_data.push(0)

    config_data.send(elec)


def transceiver_write_cfg_params(rn, sn, hw, fw, servo_target, elec: int = 0):
    """
    Writes 20 bytes config parameters into the transceiver.
    :param rn: Device Model number
    :param sn: Device Serial number
    :param hw: hardware version
    :param fw: firmware version
    :param servo_target: default implant servo target voltage level
    :param elec: electrode index (0-511)
    :return:
    """
    config_data = TransceiverConfigurationData()
    config_data.push(0x1400)  # write 20 bytes
    config_data.push(TransceiverFlashCommand.WRITE_TO_FLASH)
    config_data.push(0x0100)
    config_data.push(sn)
    config_data.push(((hw << 4) | fw) << 8)
    config_data.push(rn)
    config_data.push(0xFF00 | servo_target)

    config_data.send(elec)


def transceiver_disable_cfg_interface(elec: int = 0):
    """
    Disable configuration interface.
    """
    config_data = TransceiverConfigurationData()

    config_data.push(0x0300)  # write 3 bytes
    config_data.push(TransceiverFlashCommand.DISABLE_CFG_INTERFACE)
    config_data.push(0xFF00)

    config_data.send(elec)


def transceiver_set_bypass_mode(elec: int = 0):
    """
    Writes 4 bytes bypass data
    """
    config_data = TransceiverConfigurationData()
    config_data.push(0x0400)

    config_data.send(elec)


def transceiver_erase_cfg_flash(elec: int = 0):
    """
    Erase the configuration flash
    """
    config_data = TransceiverConfigurationData()

    config_data.push(0x0400)
    config_data.push((0x04 << 8) | TransceiverFlashCommand.CFG_ERASE_FALSH)
    config_data.push(0)

    config_data.send(elec)


def _parse_xcvr_fw_file(file):
    fw_buf_size = 16
    page = {}
    data_index = {}
    with open(file, mode='r') as f:
        lines = f.readlines()
        for line_number, line in enumerate(lines):
            if line.startswith("L"):
                page_addr = int(line[1:])
                data_index[line_number + 1] = page_addr
        for line_number in data_index:
            addr = data_index[line_number]
            page[addr] = []
            for line in lines[line_number:]:
                if line.startswith("*"):
                    break
                else:
                    for i in range(8):
                        data = int(line[i * fw_buf_size:(i + 1) * fw_buf_size],
                                   2)
                        little_endian_data = ((data & 0x00FF) << 8) | (
                                (data & 0xFF00) >> 8)
                        page[addr].append(little_endian_data)
    return page


def transceiver_write_fw_file(fw_file, elec: int = 0):
    """
    Writes the firmware update file into the transceiver.
    """
    page_data = _parse_xcvr_fw_file(fw_file)
    next_address = 0
    for addr in page_data:
        if next_address != addr:
            logger.exception("Failed to verify address. Corrupt firmware file")
        page = page_data[addr]
        transceiver_write_fw_page(page, elec)
        next_address = len(page) * 16 + addr


def transceiver_write_fw_page(page, elec: int = 0):
    """
    Writes single firmware page into transceiver.
    Each packet has 16 bytes data.
    """
    pkt_size = 8  # each packet includes 8 words
    for pkt in range(0, len(page), pkt_size):
        config_data = TransceiverConfigurationData()
        config_data.push(0x1400)  # write 20 bytes in each packet
        config_data.push(TransceiverFlashCommand.WRITE_TO_CFG_FLASH)
        config_data.push(0x0100)
        for word in range(pkt_size):
            config_data.push(page[pkt + word])

        config_data.send(elec)


def transceiver_write_prog_done(elec: int = 0):
    """
    This command will conclude firmware programming.
    """
    config_data = TransceiverConfigurationData()
    config_data.push(0x0400)
    config_data.push(TransceiverFlashCommand.PROGRAM_DONE)
    config_data.push(0)

    config_data.send(elec)


def _ensure_implant_voltage_settled(elec):
    # only useful if MIRA implant is already booted.
    transceiver_set_implant_servo_dac(DEFAULT_SERVO_DAC_LEVEL, elec)
    transceiver_power_servo_enable(True, elec)

    for _ in range(IMPLANT_BOOTING_COUNTER_MAX):
        imp_v = transceiver_get_implant_voltage(elec)
        if imp_v <= IMPLANT_VOLTAGE_STATE['default']:
            return True
        else:
            logger.debug(
                'Waiting for implant voltage to settle (imp_v={})'
                    .format(imp_v))
        time.sleep(0.33)

    return False


def ensure_implant_booted(elec: int = 0):
    """
    This function ensure that a MIRA implant is booted and settled. This
    function will return False if the implant could not be booted in the
    retry limit. True otherwise. An exception is not thrown if the implant is
    not booted. A xipppy_open context must be entered before calling this
    function.
    """
    for _ in range(IMPLANT_BOOTING_COUNTER_MAX):
        power_st = transceiver_get_power_state(elec)
        if power_st == POWER_STATE_R3['servo_enable']:
            logger.debug("Implant is booted.")
            if _ensure_implant_voltage_settled(elec):
                return True
        elif power_st == POWER_STATE_R3['idle']:
            logger.debug('Implant is down, booting.')
            transceiver_enable(elec, True)
        else:
            logger.debug('Implant is booting.')
        time.sleep(0.5)

    return False
