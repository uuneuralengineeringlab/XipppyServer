class XippPyException(Exception):
    pass


#
#  check return values or throw an error for a xipplib call
#  makes the following functions a little smaller
#

def check(n, message="Xipplib call failed"):
    """
    raise a XippPyException if the value n is negative
    """
    if n < 0:
        raise XippPyException(message)
    else:
        return n
